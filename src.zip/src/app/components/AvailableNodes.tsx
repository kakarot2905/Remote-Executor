"use client";

import React, { useState, useEffect } from "react";

interface Worker {
  workerId: string;
  status: "IDLE" | "BUSY" | "UNHEALTHY" | "OFFLINE";
  hostname: string;
  os: string;
  cpuCount: number;
  cpuUsage?: number;
  ramTotalMb?: number;
  ramFreeMb?: number;
  lastHeartbeat: number;
  currentJobIds: string[];
  reservedCpu?: number;
  reservedRamMb?: number;
  updatedAt?: number;
  dockerContainers?: number;
  dockerCpuUsage?: number;
  dockerMemoryMb?: number;
}

export default function AvailableNodes() {
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    idle: 0,
    busy: 0,
    unhealthy: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchWorkers = async () => {
      try {
        const response = await fetch("/api/workers/list");
        if (response.ok) {
          const data = await response.json();
          // Sort workers: idle first, then busy, then offline (based on heartbeat)
          const sortedWorkers = (data.workers || []).sort(
            (a: Worker, b: Worker) => {
              const now = Date.now();
              const HEARTBEAT_TIMEOUT = 15000; // 15 seconds

              const aIsOffline = now - a.lastHeartbeat > HEARTBEAT_TIMEOUT;
              const bIsOffline = now - b.lastHeartbeat > HEARTBEAT_TIMEOUT;

              // If one is offline and the other isn't, offline goes to bottom
              if (aIsOffline && !bIsOffline) return 1;
              if (!aIsOffline && bIsOffline) return -1;

              // If both are online, sort by status: idle first, then busy
              if (!aIsOffline && !bIsOffline) {
                if (a.status === "IDLE" && b.status === "BUSY") return -1;
                if (a.status === "BUSY" && b.status === "IDLE") return 1;
              }

              return 0;
            },
          );
          setWorkers(sortedWorkers);
          setStats({
            total: data.totalWorkers || 0,
            idle: data.idleWorkers || 0,
            busy: data.busyWorkers || 0,
            unhealthy: data.unhealthyWorkers || 0,
          });
        }
      } catch (error) {
        console.error("Failed to fetch workers:", error);
      } finally {
        setLoading(false);
      }
    };

    // Fetch immediately
    fetchWorkers();

    // Then poll every 3 seconds
    const interval = setInterval(fetchWorkers, 3000);

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: string) => {
    if (status === "IDLE") return "text-accent";
    if (status === "BUSY") return "text-warn";
    if (status === "UNHEALTHY") return "text-error";
    return "text-secondary";
  };

  const getOSIcon = (os: string) => {
    if (os.includes("win32")) return "🪟";
    if (os.includes("linux")) return "🐧";
    if (os.includes("darwin")) return "🍎";
    return "🖥️";
  };

  const formatTime = (timestamp: number) => {
    if (!timestamp) return "never";
    const diff = Date.now() - timestamp;
    const seconds = Math.floor(diff / 1000);
    if (seconds < 60) return `${seconds}s ago`;
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    return `${hours}h ago`;
  };

  return (
    <div className="app-panel h-full flex flex-col">
      {/* Header */}
      <div className="app-panel-header px-4 py-3 rounded-t-xl">
        <h2 className="text-accent-strong font-semibold text-lg">
          Available Nodes
        </h2>
        <div className="flex gap-4 mt-2 text-xs">
          <div className="flex items-center gap-1">
            <span className="text-accent">●</span>
            <span className="text-secondary">Idle: {stats.idle}</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-warn">●</span>
            <span className="text-secondary">Busy: {stats.busy}</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-error">●</span>
            <span className="text-secondary">Unhealthy: {stats.unhealthy}</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-secondary">●</span>
            <span className="text-secondary">Total: {stats.total}</span>
          </div>
        </div>
      </div>

      {/* Workers List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2 flex flex-col">
        {loading ? (
          <div className="text-secondary text-xs animate-pulse">
            Loading workers...
          </div>
        ) : workers.length === 0 ? (
          <div className="text-secondary text-xs">
            <p>No workers connected</p>
            <p className="text-silver mt-1">Run: node worker-agent.js</p>
          </div>
        ) : (
          workers.map((worker) => {
            const isOffline = Date.now() - worker.lastHeartbeat > 15000;
            const activeJobs = worker.currentJobIds?.length || 0;
            const statusLabel = isOffline ? "OFFLINE" : worker.status;
            return (
              <div
                key={worker.workerId}
                className={`worker-card p-2 text-xs ${
                  isOffline
                    ? "worker-card--offline"
                    : worker.status === "IDLE"
                      ? "worker-card--idle"
                      : worker.status === "BUSY"
                        ? "worker-card--busy"
                        : "worker-card--unhealthy"
                }`}
              >
                {/* Worker ID and Status */}
                <div className="flex items-center justify-between mb-1">
                  <span className="font-mono font-semibold text-accent-strong">
                    {worker.workerId}
                  </span>
                  <div className="flex items-center gap-2">
                    <span
                      className={`status-chip ${
                        isOffline
                          ? "status-chip--offline"
                          : worker.status === "IDLE"
                            ? "status-chip--idle"
                            : worker.status === "BUSY"
                              ? "status-chip--busy"
                              : "status-chip--unhealthy"
                      }`}
                    >
                      {statusLabel}
                    </span>
                    <button
                      className="glaze-button glaze-button--danger px-2 py-0.5 text-xs"
                      title="Delete node"
                      onClick={async () => {
                        const confirmDelete = window.confirm(
                          `Delete worker ${worker.workerId}? This cannot be undone.`,
                        );
                        if (!confirmDelete) return;
                        try {
                          const res = await fetch(
                            `/api/workers/${worker.workerId}`,
                            {
                              method: "DELETE",
                            },
                          );
                          if (!res.ok) {
                            const data = await res.json().catch(() => ({}));
                            throw new Error(
                              data.error || "Failed to delete worker",
                            );
                          }
                          // Optimistically update UI
                          setWorkers((prev) =>
                            prev.filter((w) => w.workerId !== worker.workerId),
                          );
                          setStats((prev) => ({
                            ...prev,
                            total: Math.max(0, prev.total - 1),
                            idle: Math.max(
                              0,
                              prev.idle - (worker.status === "IDLE" ? 1 : 0),
                            ),
                            busy: Math.max(
                              0,
                              prev.busy - (worker.status === "BUSY" ? 1 : 0),
                            ),
                            unhealthy: Math.max(
                              0,
                              prev.unhealthy -
                                (worker.status === "UNHEALTHY" ? 1 : 0),
                            ),
                          }));
                        } catch (err) {
                          console.error("Failed to delete worker:", err);
                          alert(
                            err instanceof Error
                              ? err.message
                              : "Failed to delete worker",
                          );
                        }
                      }}
                    >
                      Delete
                    </button>
                  </div>
                </div>

                {/* Worker Details */}
                <div className="space-y-0.5 text-secondary">
                  <div className="flex items-center gap-2">
                    <span>{getOSIcon(worker.os)}</span>
                    <span>{worker.os}</span>
                    <span className="text-silver">|</span>
                    <span>CPU: {worker.cpuCount}</span>
                    {worker.cpuUsage !== undefined && (
                      <span className="text-silver">
                        ({Math.round(worker.cpuUsage)}% load)
                      </span>
                    )}
                  </div>

                  <div className="text-silver">Host: {worker.hostname}</div>

                  <div className="text-silver text-xs flex gap-2">
                    <span>
                      RAM: {worker.ramFreeMb ?? "?"} /{" "}
                      {worker.ramTotalMb ?? "?"} MB free
                    </span>
                    <span className="text-silver">|</span>
                    <span>Jobs: {activeJobs}</span>
                  </div>

                  {(worker.dockerContainers ?? 0) > 0 && (
                    <div className="text-info text-1">
                      CPU: {worker.dockerCpuUsage ?? 0}% | RAM:{" "}
                      {worker.dockerMemoryMb ?? 0} MB
                    </div>
                  )}

                  <div className="flex justify-between text-silver text-xs">
                    <span>
                      Last heartbeat: {formatTime(worker.lastHeartbeat)}
                    </span>
                    {activeJobs > 0 && (
                      <span className={getStatusColor(worker.status)}>
                        Active: {activeJobs}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Footer */}
      <div className="app-panel-header px-4 py-2 text-xs text-secondary rounded-b-xl">
        <p>Auto-refreshing every 3s</p>
      </div>
    </div>
  );
}
